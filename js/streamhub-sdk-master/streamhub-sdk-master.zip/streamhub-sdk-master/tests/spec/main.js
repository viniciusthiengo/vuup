define(function () {
    'use strict';

    describe('A Streamhub SDK', function () {
    });
});