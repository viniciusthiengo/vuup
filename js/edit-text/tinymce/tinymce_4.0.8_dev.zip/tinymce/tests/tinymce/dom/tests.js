{
	"title": "tinymce.dom",
	"tests": [
		{"title": "DOMUtils", "url": "DOMUtils.html"},
		{"title": "DOMUtils (jQuery)", "url": "DOMUtils_jquery.html"},
		{"title": "EventUtils", "url": "EventUtils.html"},
		{"title": "Range (IE/Native)", "url": "Range.html"},
		{"title": "Selection", "url": "Selection.html"},
		{"title": "Serializer", "url": "Serializer.html"},
		{"title": "TridentSelection (IE)", "url": "TridentSelection.html"}
	]
}
